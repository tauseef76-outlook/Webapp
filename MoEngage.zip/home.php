<?php

session_start();
if(!isset($_SESSION['username']))
{
  header('location:index.html');
}


?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- main css -->
    <link rel="stylesheet" href="css/main.css" />
    <!-- google fonts -->
    <link
      href="https://fonts.googleapis.com/css?family=Courgette"
      rel="stylesheet"
    />

    <!-- font awesome -->
    <link rel="stylesheet" href="css/all.css" />
    <title>Restaraunt List</title>
    <style></style>
  </head>

  <body>
   <div id="mybutton">
        <h3><?php echo $_SESSION['username']; ?></h3>
        <a href="logout.php">Logout</a>
      </div>
    <div class="container">
      <div class="row">
      </div>
      <div class="row">
        <div class="col">
          <!--  button-->
          <img src="img/zomato-logo.png" class="d-block mx-auto" alt="" />
          <div class="feedback alert alert-danger text-center text-capitalize">
            please enter city
          </div>
          <form id="searchForm" class="my-4">
            <!-- form group -->
            <div class="form-group my-3">
              <select class="custom-select text-capitalize" id="searchCategory">
              </select>
            </div>
            <!-- end of form group -->

            <!-- input group -->
            <div class="input-group">
              <input
                type="text"
                class="form-control text-capitalize"
                id="searchCity"
                placeholder="enter city...."
              />
              <div class="input-group-append">
                <button type="submit" class="btn redBtn text-capitalize">
                  search
                </button>
              </div>
            </div>
            <!-- input group -->
          </form>

          <img src="img/loader.gif" class="loader" alt="" />
        </div>
      </div>
    </div>
    <!-- restaurant section -->

    <section class="py-5">
      <div class="container">
        <div class="row" id="restaurant-list">
          <!-- item -->
        </div>
      </div>
    </section>

    <!-- jquery -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- bootstrap js -->
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- script js -->
    <script src="js/app.js"></script>
  </body>
</html>
