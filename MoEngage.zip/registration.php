<?php
	session_start();
	//header('location:login.php');

	$con=mysqli_connect("localhost","root");

	if ($con) 
			{

					mysqli_select_db($con,'login');

					$name=$_POST['user'];
					$pass=$_POST['password'];

					$q="select name from signin where name='$name'";

					$result=mysqli_query($con,$q);

					$num=mysqli_num_rows($result);

					if ($num==1) {
						echo "Username is already in use. Please try with different Username";
					}
					else {
						$qy="insert into signin(name,password) values('$name','$pass') ";
						mysqli_query($con,$qy);
						echo "Registerd successfully. Please login with your Credentials ";
						
				}
				
			}
		else
			{
				echo "failed";
			}
	/*
	mysqli_select_db($con,'login');

	$name=$_POST['user'];
	$pass=$_POST['password'];

	$q="select name from signin where name='$name'";

	$result=mysqli_query($con,$q);

	$num=mysqli_num_rows($result);

	if ($num==1) {
		echo "Duplicate Data Found!!!";
	}
	else {
		$qy="insert into signin(name,password) values('$name','$pass') ";
		mysqli_query($con,$qy);
		
	}
	*/


?>