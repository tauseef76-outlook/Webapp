<?php
	session_start();
	//header('location:login.php');

	$con=mysqli_connect("localhost","root");

	if ($con)
	{
			mysqli_select_db($con,'login');

			$name=$_POST['user'];
			$pass=$_POST['password'];

			$q="select name from signin where name='$name' and password='$pass'";

			$result=mysqli_query($con,$q);

			$num=mysqli_num_rows($result);

			if ($num==1) {
				$_SESSION['username']=$name;
				header('location:home.php');
			} 
			else 
			{
				echo "Please Register First!!";;
			}
	}
	else
	{
		echo "failed";
	}
/*
	mysqli_select_db($con,'login');

	$name=$_POST['user'];
	$pass=$_POST['password'];

	$q="select name from signin where name='$name' and password='$pass'";

	$result=mysqli_query($con,$q);

	$num=mysqli_num_rows($result);

	if ($num==1) {
		$_SESSION['username']=$name;
		header('location:home.php');
	} else {
		header('location:login.php');
	}
*/


?>